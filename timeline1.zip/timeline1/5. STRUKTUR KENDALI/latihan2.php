<?php
// Pengkondisian / Percabangan
// if else
// if else if else
// ternary
// switch

// $x = 30;
// if ($x < 20) {
//     echo "benar";
// } else {
//     echo "salah";
// }

// $x = 2;
// if( $x < 20 ) {
// 	echo "benar";
// } else if( $x == 20 ) {
// 	echo "bingo!";
// } else {
// 	echo "salah";
// }

// $x = 2;
// echo $x < 20 ? 'benar' : 'salah',

// $x = 30;
// switch ($x) {
//     case $x < 20:
//         echo "benar";
//         break;
//     case $x == 20:
//         echo "benar";
//         break;
//     default:
//         echo "salah";
// }
